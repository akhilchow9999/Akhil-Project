﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.DataAccessLayer;
using Capgemini.GreatOutdoor.Entities;
/// <summary>
/// developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.BusinessLayer
{/// <summary>
/// view sales reports validations class
/// </summary>
    public class ViewSalesReportsBL
    {

        /// <summary>
        /// lists all the sales persons reports
        /// </summary>
        /// <returns></returns>
        public async Task<List<ViewSalesReports>> ViewAllSalesReportsBL()
        {
            ViewSalesReportsDAL salesreports = new ViewSalesReportsDAL();
            List<ViewSalesReports> viewSales = new List<ViewSalesReports>();

            try
            {

                viewSales = await salesreports.ViewAllSalesReportsDAL();
            }
            catch (Exception)
            {
                throw;
            }
            return viewSales;

        }

    }
}


﻿using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    ///  Developed by -Prafull Sharma
    /// Contains data access layer methods for inserting, updating, deleting retailers from Retailers collection.
    /// </summary>
    public class RetailerDAL : RetailerDALBase, IDisposable
    {
        //creating SqlConnection object
        SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
        /// <summary>
        /// Adds new retailer to Retailers collection.
        /// Developed by Prafull Sharma
        /// </summary>
        /// <param name="newRetailer">Contains the retailer details to be added.</param>
        /// <returns>Determinates whether the new retailer is added.</returns>
        public override (bool, Guid) AddRetailerDAL(Retailer newRetailer)
        {
           // SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {
                sqlConn.Open();
                bool retailerAdded = false;
                Guid RetailerGuid;
                try
                {
                    RetailerGuid = Guid.NewGuid();
                    newRetailer.RetailerID = RetailerGuid;
                    newRetailer.CreationDateTime = DateTime.Now;
                    newRetailer.LastModifiedDateTime = DateTime.Now;
                    SqlCommand sqlCmd = new SqlCommand("TeamB.AddRetailer", sqlConn);
                    //(@retailerID, @retailerName, @retailerEmail,@password , @retailerMobile, @CreationDateTime , @LastModifiedDateTime)
                    sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@retailerID", RetailerGuid);
                    sqlCmd.Parameters.AddWithValue("@retailerName", newRetailer.RetailerName);
                    sqlCmd.Parameters.AddWithValue("@retailerEmail", newRetailer.Email);
                    sqlCmd.Parameters.AddWithValue("@password", newRetailer.Password);
                    sqlCmd.Parameters.AddWithValue("@retailerMobile", newRetailer.RetailerMobile);
                    sqlCmd.Parameters.AddWithValue("@CreationDateTime", newRetailer.CreationDateTime);
                    sqlCmd.Parameters.AddWithValue("@LastModifiedDateTime", newRetailer.LastModifiedDateTime);
                    //creating object of sql data reader
                    Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                    if(isadded>0)
                    { retailerAdded = true; }
                    else
                    { retailerAdded = false; }
                    sqlConn.Close();

                }
                catch (Exception)
                {
                    throw;
                }
                return (retailerAdded, RetailerGuid);
            }
            catch (Exception )
            {
                throw; 
            }
            
        }

        /// <summary>
        /// Gets all retailers from the collection.
        /// </summary>
        /// <returns>Returns list of all retailers.</returns>
        public override List<Retailer> GetAllRetailersDAL()
        {
            sqlConn.Open();
            List<Retailer> retailerList = new List<Retailer>();
            try
            {
                // Create SQL Command
                SqlCommand sqlCmd = new SqlCommand("select* from TeamB.Retailers", sqlConn);
                sqlCmd.CommandType =CommandType.Text;
                //creating object of data Command type
                //Exccute Query
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                //Get Data into list
                while (reader.Read())
                {
                    Retailer mretailer = new Retailer();
                    mretailer.RetailerID = new Guid(reader["RetailerID"].ToString());
                    mretailer.RetailerName = reader["RetailerName"].ToString();
                    mretailer.Email = reader["RetailerEmail"].ToString();
                    mretailer.Password = reader["Password"].ToString();
                    mretailer.RetailerMobile = reader["RetailerMobile"].ToString();
                    mretailer.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    mretailer.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    retailerList.Add(mretailer);
                }
                sqlConn.Close();
                return retailerList;
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        /// <summary>
        /// Gets retailer based on RetailerID.
        /// Developed by - Ayush Agrawal
        /// </summary>
        /// <param name="searchRetailerID">Represents RetailerID to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByRetailerIDDAL(Guid searchRetailerID)
        {
            sqlConn.Open();
            Retailer matchingRetailer = null;
            try
            {
                //Creating Sql Connection
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetReatilerByReatilerID", sqlConn);
                sqlCmd.Parameters.AddWithValue("@retailerID", searchRetailerID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of Command Type
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    Retailer mretailer = new Retailer();
                    mretailer.RetailerID = searchRetailerID;
                    mretailer.RetailerName = reader["RetailerName"].ToString();
                    mretailer.Email = reader["RetailerEmail"].ToString();
                    mretailer.Password = reader["Password"].ToString();
                    mretailer.RetailerMobile = reader["RetailerMobile"].ToString();
                    mretailer.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    mretailer.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingRetailer = mretailer;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Gets retailer based on RetailerName.
        /// Developed by Prafull Sharma
        /// </summary>
        /// <param name="retailerName">Represents RetailerName to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public override List<Retailer> GetRetailersByNameDAL(string retailerName)
        {
            List<Retailer> matchingRetailers = new List<Retailer>();
            try
            {
                //Find All Retailers based on retailerName
                //Creaing SQL Connection
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetReatilerByName", sqlConn);
                sqlCmd.Parameters.AddWithValue("@retailerName", retailerName);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of Command Type
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    Retailer mretailer = new Retailer();
                    mretailer.RetailerID = new Guid(reader["RetailerID"].ToString());
                    mretailer.RetailerName = reader["RetailerName"].ToString();
                    mretailer.Email = reader["RetailerEmail"].ToString();
                    mretailer.Password = reader["Password"].ToString();
                    mretailer.RetailerMobile = reader["RetailerMobile"].ToString();
                    mretailer.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    mretailer.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingRetailers.Add(mretailer);
                }
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return matchingRetailers;
        }

        /// <summary>
        /// Gets retailer based on email.
        /// Developed by Prfull Sharma
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByEmailDAL(string email)
        {
            sqlConn.Open();
            Retailer matchingRetailer = null;
            try
            {
                //Creating Sql Connection
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetReatilerByEmail", sqlConn);
                sqlCmd.Parameters.AddWithValue("@retailerEmail", email);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of sql Command
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    Retailer mretailer = new Retailer();
                    mretailer.RetailerID = new Guid(reader["RetailerID"].ToString());
                    mretailer.RetailerName = reader["RetailerName"].ToString();
                    mretailer.Email = reader["RetailerEmail"].ToString();
                    mretailer.Password = reader["Password"].ToString();
                    mretailer.RetailerMobile = reader["RetailerMobile"].ToString();
                    mretailer.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    mretailer.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingRetailer = mretailer;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Gets retailer based on Email and Password.
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <param name="password">Represents Retailer's Password.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByEmailAndPasswordDAL(string email, string password)
        {

            sqlConn.Open();
            Retailer matchingRetailer = null;
            try
            {
                //Creating SQL Connection 
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetReatilerByEmailAndPassword", sqlConn);
                sqlCmd.Parameters.AddWithValue("@retailerEmail", email);
                sqlCmd.Parameters.AddWithValue("@password", password);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of sql Command
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    Retailer mretailer = new Retailer();
                    mretailer.RetailerID = new Guid(reader["RetailerID"].ToString());
                    mretailer.RetailerName = reader["RetailerName"].ToString();
                    mretailer.Email = reader["RetailerEmail"].ToString();
                    mretailer.Password = reader["Password"].ToString();
                    mretailer.RetailerMobile = reader["RetailerMobile"].ToString();
                    mretailer.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    mretailer.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingRetailer = mretailer;
                }
                sqlConn.Close();
            }
            catch (Exception e)
            {

                throw ;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Updates retailer based on RetailerID.
        /// Developed by prafull Sharma
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, RetailerName etc.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public override bool UpdateRetailerDAL(Retailer updateRetailer)
        {
            bool retailerUpdated = false;
            try
            {
                //Find Retailer based on RetailerID
                Retailer matchingRetailer = GetRetailerByRetailerIDDAL(updateRetailer.RetailerID);

                if (matchingRetailer != null)
                {
                    //Update retailer details
                    ReflectionHelpers.CopyProperties(updateRetailer, matchingRetailer, new List<string>() { "RetailerName", "Email" });
                    matchingRetailer.LastModifiedDateTime = DateTime.Now;
                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            // Creating SQL CONNECTION
                            SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateRetailer", sqlConn);
                            //(@retailerID, @retailerName, @retailerEmail,@password , @retailerMobile, @CreationDateTime , @LastModifiedDateTime)
                            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                            //creating object of Command Type
                            sqlCmd.Parameters.AddWithValue("@retailerID", matchingRetailer.RetailerID);
                            sqlCmd.Parameters.AddWithValue("@retailerName", matchingRetailer.RetailerName);
                            sqlCmd.Parameters.AddWithValue("@retailerEmail", matchingRetailer.Email);
                            sqlCmd.Parameters.AddWithValue("@password", matchingRetailer.Password);
                            sqlCmd.Parameters.AddWithValue("@retailerMobile", matchingRetailer.RetailerMobile);
                            sqlCmd.Parameters.AddWithValue("@CreationDateTime", matchingRetailer.CreationDateTime);
                            sqlCmd.Parameters.AddWithValue("@LastModifiedDateTime", matchingRetailer.LastModifiedDateTime);
                            Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                            //creating object of data reader
                            if (isadded > 0)
                            { retailerUpdated = true; }
                            else
                            { retailerUpdated = false; }
                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (retailerUpdated);
                    }

                    catch (Exception)
                    { throw; }

                }
            }
            catch (Exception)
            {
                throw;
            }
            return retailerUpdated;
        }

        /// <summary>
        /// Deletes retailer based on RetailerID.
        /// </summary>
        /// Developed By Prafull Sharma
        /// <param name="deleteRetailerID">Represents RetailerID to delete.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public override bool DeleteRetailerDAL(Guid deleteRetailerID)
        {
            sqlConn.Open();
            bool retailerDeleted = false;
            try
            { 
                // Creating SQL CONNECTION
                SqlCommand sqlCmd = new SqlCommand(" TeamB.DeleteRetailer", sqlConn);
                //(@retailerID, @retailerName, @retailerEmail,@password , @retailerMobile, @CreationDateTime , @LastModifiedDateTime)
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of Sql Command
                sqlCmd.Parameters.AddWithValue("@retailerID", deleteRetailerID);
                Int16 isdeleted = Convert.ToInt16(sqlCmd.ExecuteScalar());
                //creating object of data reader
                if (isdeleted > 0)
                { retailerDeleted = true; }
                else
                { retailerDeleted = false; }
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return retailerDeleted;
        }

        /// <summary>
        /// Updates retailer's password based on RetailerID.
        /// Developed by prafull Sharma
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, Password.</param>
        /// <returns>Determinates whether the existing retailer's password is updated.</returns>
        public override bool UpdateRetailerPasswordDAL(Retailer updateRetailer)
        {
            bool passwordUpdated = false;
            try
            {
                //Find Retailer based on RetailerID
                Retailer matchingRetailer = GetRetailerByRetailerIDDAL(updateRetailer.RetailerID);

                if (matchingRetailer != null)
                {
                    //Update retailer details
                    ReflectionHelpers.CopyProperties(updateRetailer, matchingRetailer, new List<string>() { "Password" });
                    matchingRetailer.LastModifiedDateTime = DateTime.Now;
                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            //Creating Sql Connection
                            SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateRetailer", sqlConn);
                            //(@retailerID, @retailerName, @retailerEmail,@password , @retailerMobile, @CreationDateTime , @LastModifiedDateTime)
                            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                            //Creating object of sql Command
                            sqlCmd.Parameters.AddWithValue("@retailerID", matchingRetailer.RetailerID);
                            sqlCmd.Parameters.AddWithValue("@retailerName", matchingRetailer.RetailerName);
                            sqlCmd.Parameters.AddWithValue("@retailerEmail", matchingRetailer.Email);
                            sqlCmd.Parameters.AddWithValue("@password", matchingRetailer.Password);
                            sqlCmd.Parameters.AddWithValue("@retailerMobile", matchingRetailer.RetailerMobile);
                            sqlCmd.Parameters.AddWithValue("@CreationDateTime", matchingRetailer.CreationDateTime);
                            sqlCmd.Parameters.AddWithValue("@LastModifiedDateTime", matchingRetailer.LastModifiedDateTime);
                            Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                            //creating object of data reader
                            if (isadded > 0)
                            { passwordUpdated = true; }
                            else
                            { passwordUpdated = false; }
                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (passwordUpdated);
                    }

                    catch (Exception)
                    { throw; }

                }
            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}




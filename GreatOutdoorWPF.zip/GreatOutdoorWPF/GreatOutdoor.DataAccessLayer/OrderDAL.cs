﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    //Developed By C AKhil Chowdary
    /// <summary>
    /// Contains data access layer methods for inserting, updating orders from ordersList collection.
    /// </summary>
    public class OrderDAL : OrderDALBase, IDisposable
    {
        //sql connection object
        private SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);

        /// <summary>
        /// Adds new order to ordersList collection.
        /// </summary>
        /// <param name="newOrder">Contains the order details to be added.</param>
        /// <returns>Determinates whether the new order is added.</returns>
        public override (bool, Guid) AddOrderDAL(Order newOrder)
        {
            sqlConnection.Open();
            bool orderAdded = false;
            try
            {
                //assigning values to order object
                newOrder.OrderId = Guid.NewGuid();
                newOrder.OrderNumber = ordersList.Count + 1;
                newOrder.DateOfOrder = DateTime.Now;
                newOrder.LastModifiedDateTime = DateTime.Now;
                ordersList.Add(newOrder);
                orderAdded = true;

                //SqlCommand object creation
                string query = "TeamB.AddOrder";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                //OrderId parameter adding
                SqlParameter paramOrderId = new SqlParameter();
                paramOrderId.ParameterName = "@orderId";
                paramOrderId.Value = newOrder.OrderId;
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                //RetailerId parameter adding
                SqlParameter paramRetailerId = new SqlParameter("@retailerId", newOrder.RetailerID);
                paramRetailerId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramRetailerId);

                //adding date of order, total quantity, order amount, last modified date parameters
                sqlCommand.Parameters.AddWithValue("@dateOfOrder", newOrder.DateOfOrder);
                sqlCommand.Parameters.AddWithValue("@totalQuantity", newOrder.TotalQuantity);
                sqlCommand.Parameters.AddWithValue("@orderAmount", newOrder.OrderAmount);
                sqlCommand.Parameters.AddWithValue("@lastModifiedDate", newOrder.LastModifiedDateTime);

                SqlParameter sqlParameter = new SqlParameter();
                sqlParameter.SqlDbType = SqlDbType.Int;
                sqlParameter.Direction = ParameterDirection.ReturnValue;
                sqlCommand.Parameters.Add(sqlParameter);
                
                //execuuting sql command
                sqlCommand.ExecuteNonQuery();
                int ret = (int)(sqlParameter.Value);
                //closing connection
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return (orderAdded, newOrder.OrderId);
        }

        /// <summary>
        /// Constructor for OrderDAL
        /// </summary>
        public OrderDAL()
        {

        }
        
        /// <summary>
        /// Gets Order based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns Order object.</returns>
        public override Order GetOrderByOrderIDDAL(Guid searchOrderID)
        {
            Order order = new Order();
            try
            {
                //SqlCommand object creation
                string query = "TeamB.ViewOrderByOrderID";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.Connection = sqlConnection;

                //adding searchOrderId parameter
                SqlParameter paramOrderId = new SqlParameter("@orderId", searchOrderID);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                //connection open
                sqlConnection.Open();

                //sql datareader
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {
                    order.OrderId = sqlDataReader.GetGuid(0);
                    order.RetailerID = sqlDataReader.GetGuid(1);
                    order.DateOfOrder = sqlDataReader.GetDateTime(2);
                    order.TotalQuantity = sqlDataReader.GetInt32(3);
                    order.OrderAmount = Double.Parse(sqlDataReader["OrderAmount"].ToString());
                    order.LastModifiedDateTime = sqlDataReader.GetDateTime(5);
                    order.OrderNumber = sqlDataReader.GetInt32(6);
                }
                //closing data reader
                sqlDataReader.Close();

                //closing connection
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return order;
        }

        /// <summary>
        /// Gets Order by OrderNumber
        /// </summary>
        /// <param name="orderNumber">represents the OrderNumber to be searched</param>
        /// <returns></returns>
        public override Order GetOrderByOrderNumberDAL(int orderNumber)
        {
            Order order = new Order();
            try
            {
                //SqlCommand object creation                
                string query = "TeamB.ViewOrderByOrderNumber";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                //assigning parameters
                SqlParameter paramOrderNumber = new SqlParameter("@orderNumber", orderNumber);
                paramOrderNumber.SqlDbType = SqlDbType.Int;
                sqlCommand.Parameters.Add(paramOrderNumber);
                //connection open
                sqlConnection.Open();
                //data reader object
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                //loading data
                while (sqlDataReader.Read())
                {
                    order.OrderId = sqlDataReader.GetGuid(0);
                    order.RetailerID = sqlDataReader.GetGuid(1);
                    order.DateOfOrder =  sqlDataReader.GetDateTime(2);
                    order.TotalQuantity = sqlDataReader.GetInt32(3);
                    order.OrderAmount = Double.Parse(sqlDataReader["OrderAmount"].ToString());
                    order.LastModifiedDateTime = sqlDataReader.GetDateTime(5);
                    order.OrderNumber = sqlDataReader.GetInt32(6);
                }
                //closing data reader
                sqlDataReader.Close();
                //connection closing
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return order;
        }

        /// <summary>
        /// Gets all orders placed
        /// </summary>
        /// <returns></returns>
        public List<Order> GetAllOrders()
        {
            try
            {
                List<Order> orders = new List<Order>();

                //SqlCommand object creation
                string query = "exec TeamB.GetAllOrders";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                //dataset object creation
                DataSet dataSet = new DataSet();
                //data adapter object
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                //filling data adapter
                sqlDataAdapter.Fill(dataSet);
                //data row object
                DataRow dataRow;
                //loading data
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    Order order = new Order();
                    order.OrderId = Guid.Parse(dataRow["OrderId"].ToString());
                    order.OrderAmount = Convert.ToDouble(dataRow["OrderAmount"]);
                    order.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    order.DateOfOrder = Convert.ToDateTime(dataRow["DateOfOrder"]);
                    order.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDate"]);
                    order.OrderNumber = Convert.ToInt32(dataRow["OrderNumber"]);
                    orders.Add(order);
                }
                return orders;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// gets the orders of a retailer
        /// </summary>
        /// <param name="searchRetailerID">represents the retiler id whose orders are to be fetched</param>
        /// <returns></returns>
        public override List<Order> GetOrdersByRetailerIDDAL(Guid searchRetailerID)
        {
            List<Order> matchingOrder = new List<Order>();
            try
            {
                //Find Order based on searchOrderID
                sqlConnection.Open();
                //SqlCommand object creation
                string query = "TeamB.ViewRetailerOrders";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                //RetailerId parameter adding
                SqlParameter paramRetailerID = new SqlParameter();
                paramRetailerID.ParameterName = "@retailerID";
                paramRetailerID.Value = searchRetailerID;
                paramRetailerID.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(paramRetailerID);
               // sqlCommand.ExecuteNonQuery();
                //data set object
                DataSet dataSet = new DataSet();
                //data adapter object
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                //filling dataset
                sqlDataAdapter.Fill(dataSet);
                sqlConnection.Close();
                //datarow object
                DataRow dataRow;
                //loadaing data
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    Order order = new Order();
                    //order.OrderId = dataRow["OrderId"];
                    order.OrderAmount = Convert.ToDouble(dataRow["OrderAmount"]);
                    order.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    order.DateOfOrder = Convert.ToDateTime(dataRow["DateOfOrder"]);
                    order.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDateTime"]);
                    order.OrderNumber = Convert.ToInt32(dataRow["OrderNumber"]);
                    matchingOrder.Add(order);
                }
                return matchingOrder;

            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Updates Order based on OrderID.
        /// </summary>
        /// <param name="updateOrder">Represents Order details like OrderID</param>
        /// <returns>Determinates whether the existing Order is updated.</returns>
        public override bool UpdateOrderDAL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                //Find Order based on OrderID
                Order order = GetOrderByOrderIDDAL(updateOrder.OrderId);

                if (order != null)
                {
                    //SqlCommand object creation
                    string query = "TeamB.UpdateOrder";
                    SqlCommand sqlCommand = new SqlCommand(query);
                    sqlCommand.Connection = sqlConnection;
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    //adding OrderId parameter
                    SqlParameter paramOrderId = new SqlParameter("@orderId", updateOrder.OrderId);
                    paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                    sqlCommand.Parameters.Add(paramOrderId);
                    //adding other parameters
                    sqlCommand.Parameters.AddWithValue("@orderAmount", updateOrder.OrderAmount);
                    sqlCommand.Parameters.AddWithValue("@totalQuantity", updateOrder.TotalQuantity);
                    sqlCommand.Parameters.AddWithValue("@lastModifiedDate", updateOrder.LastModifiedDateTime);

                    //connection open
                    sqlConnection.Open();

                    //execuuting sql command
                    sqlCommand.ExecuteNonQuery();

                    //closing connection
                    sqlConnection.Close();

                    orderUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderUpdated;
        }



        /// <summary>
        /// Deletes order based on OrderID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderID to delete.</param>
        /// <returns>Determinates whether the existing order is updated.</returns>
        public override bool DeleteOrderDAL(Guid deleteOrderID)
        {
            bool orderDeleted = false;
            try
            {
                //Find Order based on orderID
                //Order matchingOrder = ordersList.Find(
                //    (item) => { return item.OrderId == deleteOrderID; }
                //);

                //if (matchingOrder != null)
                //{


                //SqlCommand object creation
                string query = "TeamB.DeleteOrder";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                //adding OrderId parameter
                SqlParameter paramOrderId = new SqlParameter("@orderId", deleteOrderID);
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                //connection open
                sqlConnection.Open();

                //execuuting sql command
                sqlCommand.ExecuteNonQuery();

                //closing connection
                sqlConnection.Close();
                //}
            }
            catch (Exception)
            {
                throw;
            }
            return orderDeleted;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Developed by - Ayush Agrawal
    /// Contains data access layer methods for inserting, updating, deleting salesPersons from SalesPersons collection.
    /// </summary>
    public class SalesPersonDAL : SalesPersonDALBase, IDisposable
    {
        /// <summary>
        /// Adds new salesPerson to SalesPersons collection.
        /// Developed by Ayush Agrawal
        /// </summary>
        /// <returns>Determinates whether the new salesPerson is added.</returns>
        public override (bool, Guid) AddSalesPersonDAL(SalesPerson newSalesPerson)
        {
            bool salesPersonAdded = false;
            try
            {
                newSalesPerson.SalesPersonID = Guid.NewGuid();
                newSalesPerson.CreationDateTime = DateTime.Now;
                newSalesPerson.LastModifiedDateTime = DateTime.Now;
                //creating SqlConnection object
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "TeamB.AddSalesPerson";
                SqlCommand sqlCmd = new SqlCommand(query, sqlConnection);
                //creating object of sql Command
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@salesPersonID", newSalesPerson.SalesPersonID);
                sqlCmd.Parameters.AddWithValue("@salesPersonName", newSalesPerson.SalesPersonName);
                sqlCmd.Parameters.AddWithValue("@email", newSalesPerson.Email);
                sqlCmd.Parameters.AddWithValue("@salesPersonMobile", newSalesPerson.SalesPersonMobile);
                sqlCmd.Parameters.AddWithValue("@password", newSalesPerson.Password);
                sqlCmd.Parameters.AddWithValue("@creationDateTime", newSalesPerson.CreationDateTime);
                sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", newSalesPerson.LastModifiedDateTime);
                //creating object of sql data reader
                Int32 isadded = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (isadded > 0)
                {
                    salesPersonAdded = true;
                }
                else
                {
                    salesPersonAdded = false;

                }
                sqlConnection.Close();
                return (salesPersonAdded, newSalesPerson.SalesPersonID);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Updates salesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, SalesPersonName etc.</param>
        /// <returns>Determinates whether the existing salesPerson is updated.</returns>
        public override bool UpdateSalesPersonDAL(SalesPerson updateSalesPerson)
        {
            bool salesPersonUpdated = false;
            try
            {
                //Find SalesPerson based on SalesPersonID
                SalesPerson matchingSalesPerson = GetSalesPersonBySalesPersonIDDAL(updateSalesPerson.SalesPersonID);

                if (matchingSalesPerson != null)
                {
                    //Update salesPerson details
                    ReflectionHelpers.CopyProperties(updateSalesPerson, matchingSalesPerson, new List<string>() { "SalesPersonName", "Email" });
                    matchingSalesPerson.LastModifiedDateTime = DateTime.Now;
                    //Creating Sql Connection
                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            // Creating object of Sql Command
                            SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateSalesPerson", sqlConn);
                            //@salesPersonID, @salespersonName, @email, @password, @salesPersonMobile, @creationDateTime, @lastModifiedDateTime

                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("@salesPersonID", matchingSalesPerson.SalesPersonID);
                            sqlCmd.Parameters.AddWithValue("@salesPersonName", matchingSalesPerson.SalesPersonName);
                            sqlCmd.Parameters.AddWithValue("@email", matchingSalesPerson.Email);
                            sqlCmd.Parameters.AddWithValue("@salesPersonMobile", matchingSalesPerson.SalesPersonMobile);
                            sqlCmd.Parameters.AddWithValue("@password", matchingSalesPerson.Password);
                            sqlCmd.Parameters.AddWithValue("@creationDateTime", matchingSalesPerson.CreationDateTime);
                            sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", matchingSalesPerson.LastModifiedDateTime);
                            Int32 isupdated = Convert.ToInt32(sqlCmd.ExecuteScalar());
                            //Creating object of Data reader
                            if (isupdated > 0)
                            {
                                salesPersonUpdated = true;
                            }
                            else
                            {
                                salesPersonUpdated = false;

                            }
                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (salesPersonUpdated);
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return salesPersonUpdated;
        }


        /// <summary>
        /// Deletes salesPerson based on SalesPersonID.
        /// Developed by -Ayush Agrawal
        /// </summary>
        /// <param name="deleteSalesPersonID">Represents SalesPersonID to delete.</param>
        /// <returns>Determinates whether the existing salesPerson is updated.</returns>
        public override bool DeleteSalesPersonDAL(Guid deleteSalesPersonID)
        {
            //Creating Sql Connection
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            bool salesPersonDeleted = false;
            try
            {
                // Creating SQL Command
                SqlCommand sqlCmd = new SqlCommand(" TeamB.DeleteSalesPerson", sqlConn);
              
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
               
                sqlCmd.Parameters.AddWithValue("@salsPersonID", deleteSalesPersonID);
                Int16 isdeleted = Convert.ToInt16(sqlCmd.ExecuteScalar());
       
                //creating object of data reader
                if (isdeleted > 0)
                { salesPersonDeleted = true; }
                else
                { salesPersonDeleted = false; }
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return salesPersonDeleted;
        }



        /// <summary>
        /// Gets all salesPersons from the collection.
        /// Developed by Ayush Agrawal
        /// </summary>
        /// <returns>Returns list of all salesPersons.</returns>
        public override List<SalesPerson> GetAllSalesPersonsDAL()
        {
            try
            {
                List<SalesPerson> salesPerson = new List<SalesPerson>();
                //creating Sql connction
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                string query = "TeamB.GetAllSalesPerson";
                 SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                //creating object of data command Type
                DataSet dataSet = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                sqlDataAdapter.Fill(dataSet);
                //filling Data Set
                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    SalesPerson salesPersons = new SalesPerson();
                    salesPersons.SalesPersonID = new Guid(Convert.ToString(dataRow["SalesPersonId"]));
                    salesPersons.SalesPersonName = Convert.ToString(dataRow["SalesPersonName"]);
                    salesPersons.SalesPersonMobile = Convert.ToString(dataRow["SalesPersonMobile"]);
                    salesPersons.Email = Convert.ToString(dataRow["Email"]);
                    salesPersons.Password = Convert.ToString(dataRow["Password"]);
                    salesPersons.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDateTime"]);
                    salesPersons.CreationDateTime = Convert.ToDateTime(dataRow["CreationDateTime"]);
                    salesPerson.Add(salesPersons);
                }
                return salesPerson;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Gets salesPerson based on SalesPersonID.
        /// Developed by Ayush Agrawal
        /// </summary>
        /// <param name="searchSalesPersonID">Represents SalesPersonID to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public override SalesPerson GetSalesPersonBySalesPersonIDDAL(Guid searchSalesPersonID)
        {
            //creating Sql Connection
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            SalesPerson matchingSalesPerson = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetSalesPersonBySalesPersonIDDAL", sqlConn);
                sqlCmd.Parameters.AddWithValue("@salesPersonID", searchSalesPersonID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of data command type
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    SalesPerson msalesPerson = new SalesPerson();
                    msalesPerson.SalesPersonID = searchSalesPersonID;
                    msalesPerson.SalesPersonName = reader["SalesPersonName"].ToString();
                    msalesPerson.Email = reader["Email"].ToString();
                    msalesPerson.Password = reader["Password"].ToString();
                    msalesPerson.SalesPersonMobile = reader["SalesPersonMobile"].ToString();
                    msalesPerson.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    msalesPerson.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingSalesPerson = msalesPerson;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets salesPerson based on SalesPersonName.
        /// Developd by Ayush Agrawal
        /// </summary>
        /// <param name="salesPersonName">Represents SalesPersonName to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public override SalesPerson GetSalesPersonsByNameDAL(string salespersonName)
        {
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();

            SalesPerson matchingSalesPerson = null;
            try
            {
                //Creating Sql Connection
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetSalesPersonBySalesPersonID4", sqlConn);
                sqlCmd.Parameters.AddWithValue("@SalesPerson", salespersonName);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of data CommandType
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    SalesPerson msalesPerson = new SalesPerson();
                    msalesPerson.SalesPersonID = new Guid(reader["SalesPersonID"].ToString()); ;
                    msalesPerson.SalesPersonName = reader["SalesPersonName"].ToString();
                    msalesPerson.Email = reader["Email"].ToString();
                    msalesPerson.Password = reader["Password"].ToString();
                    msalesPerson.SalesPersonMobile = reader["SalesPersonMobile"].ToString();
                    msalesPerson.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    msalesPerson.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingSalesPerson = msalesPerson;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingSalesPerson;
        }
        /// <summary>
        /// Gets salesPerson based on email.
        /// Developed by Ayush Agrawal
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public override SalesPerson GetSalesPersonByEmailDAL(string email)
        {
            //creating sql connection
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();

            SalesPerson matchingSalesPerson = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetSalesPersonByEmail", sqlConn);
                sqlCmd.Parameters.AddWithValue("@email", email);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of data Command Type
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    SalesPerson msalesPerson = new SalesPerson();
                    msalesPerson.SalesPersonID = new Guid(reader["SalesPersonID"].ToString()); ;
                    msalesPerson.SalesPersonName = reader["SalesPersonName"].ToString();
                    msalesPerson.Email = reader["Email"].ToString();
                    msalesPerson.Password = reader["Password"].ToString();
                    msalesPerson.SalesPersonMobile = reader["SalesPersonMobile"].ToString();
                    msalesPerson.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    msalesPerson.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingSalesPerson = msalesPerson;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets salesPerson based on Email and Password.
        /// Developed by Ayush Agrawal
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <param name="password">Represents SalesPerson's Password.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public override SalesPerson GetSalesPersonByEmailAndPasswordDAL(string email, string password)
        {
          //  creating Sql Connection

            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            SalesPerson matchingSalesPerson = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetSalesPersonByEmailAndPassword", sqlConn);
                sqlCmd.Parameters.AddWithValue("@Email", email);
                sqlCmd.Parameters.AddWithValue("@password", password);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                //creating object of data command Type
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of data reader
                while (reader.Read())
                {
                    SalesPerson msalesPerson = new SalesPerson();
                    msalesPerson.SalesPersonID = new Guid(reader["SalesPersonID"].ToString()); ;
                    msalesPerson.SalesPersonName = reader["SalesPersonName"].ToString();
                    msalesPerson.Email = reader["Email"].ToString();
                    msalesPerson.Password = reader["Password"].ToString();
                    msalesPerson.SalesPersonMobile = reader["SalesPersonMobile"].ToString();
                    msalesPerson.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    msalesPerson.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingSalesPerson = msalesPerson;
                }
                sqlConn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            return matchingSalesPerson;
        }



        /// <summary>
        /// Updates salesPerson's password based on SalesPersonID.
        /// Dvelopd by - Ayush Agrawal
        /// </summary>
        /// <param name="updateSalesPersonPassword">Represents SalesPerson details including SalesPersonID, Password.</param>
        /// <returns>Determinates whether the existing salesPerson's password is updated.</returns>
        public override bool UpdateSalesPersonPasswordDAL(SalesPerson updateSalesPerson)
        {
            bool passwordUpdated = false;
            try
            {
                //Find SalesPerson based on SalesPersonID
                SalesPerson matchingSalesPerson = GetSalesPersonBySalesPersonIDDAL(updateSalesPerson.SalesPersonID);

                if (matchingSalesPerson != null)
                {
                    //Update salesPerson details
                    ReflectionHelpers.CopyProperties(updateSalesPerson, matchingSalesPerson, new List<string>() { "Password" });
                    matchingSalesPerson.LastModifiedDateTime = DateTime.Now;
                    //Creatind Sql Connection
                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateSalesPersonPassword", sqlConn);
                            //@salesPersonID, @salespersonName, @email, @password, @salesPersonMobile, @creationDateTime, @lastModifiedDateTime
                            //creating object of data command Type
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("@salesPersonID", matchingSalesPerson.SalesPersonID);
                            sqlCmd.Parameters.AddWithValue("@salesPersonName", matchingSalesPerson.SalesPersonName);
                            sqlCmd.Parameters.AddWithValue("@Email", matchingSalesPerson.Email);
                            sqlCmd.Parameters.AddWithValue("@salesPersonMobile", matchingSalesPerson.SalesPersonMobile);
                            sqlCmd.Parameters.AddWithValue("@password", matchingSalesPerson.Password);
                            sqlCmd.Parameters.AddWithValue("@creationDateTime", matchingSalesPerson.CreationDateTime);
                            sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", matchingSalesPerson.LastModifiedDateTime);
                            Int32 isadded = Convert.ToInt32(sqlCmd.ExecuteScalar());
                            //creating object of data reader
                            if (isadded > 0)
                            {
                                passwordUpdated = true;
                            }
                            else
                            {
                                passwordUpdated = false;

                            }
                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (passwordUpdated);
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}





﻿using System;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.Entities;
/// <summary>
/// developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.Contracts.BLContracts
{
    public interface IAdminBL : IDisposable
    {
        /// <summary>
        /// gets admin by email and password
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        Task<Admin> GetAdminByEmailAndPasswordBL(string email, string password);

        /// <summary>
        /// updates admin based on admin id
        /// </summary>
        /// <param name="updateAdmin"></param>
        /// <returns></returns>
        Task<bool> UpdateAdminBL(Admin updateAdmin);

        /// <summary>
        /// updates admin password based on email and password
        /// </summary>
        /// <param name="updateAdmin"></param>
        /// <returns></returns>
        Task<bool> UpdateAdminPasswordBL(Admin updateAdmin);

        /// <summary>
        /// gets admin by admin email
        /// </summary>
        /// <param name="Email"></param>
        /// <returns></returns>
        Task<Admin> GetAdminByAdminEmailBL(string Email);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capgemini.GreatOutdoor.Entities
{
    //Developed By : Abhishek
    //Use case: Upload Offline Orders
    //Project: GreatOutdoors

    public interface IOfflineOrderDetail
    {
        Guid OfflineOrderDetailID { get; set; } //ID is generated in Data Access layer while adding Detail 
        Guid ProductID { get; set; }            //ID coming from pre generated list
        string ProductName { get; set; }
        int Quantity { get; set; }              //Quantity of Particular product in Order
        double UnitPrice { get; set; }
        double TotalPrice { get; set; }
        Guid OfflineOrderID { get; set; }       //Offline Order ID which contains all correponding Offline Order
    }

    public class OfflineOrderDetail
    {
        public Guid OfflineOrderDetailID { get; set; }
        public Guid ProductID { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public double UnitPrice { get; set; }
        public double TotalPrice { get; set; }
        public Guid OfflineOrderID { get; set; }
    }
}
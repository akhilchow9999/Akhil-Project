﻿using System;
using System.Collections.Generic;
using System.Text;
using Capgemini.GreatOutdoor.Helpers.ValidationAttributes;
namespace Capgemini.GreatOutdoor.Entities
{
    //Developed By : Abhishek
    //Use case: Upload Offline Orders
    //Project: GreatOutdoors

    //Interface of Offline Order
    public interface IOfflineOrder
    {
        Guid OfflineOrderID { get; set; }  //  Offline Order ID:Generation in Data Access Layer
        Guid RetailerID { get; set; }      // Retailer ID from PreExisting List
        Guid SalesPersonID { get; set; }   // Current SalesPersonID
        double TotalOrderAmount { get; set; } //Total Order Amount
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
        double TotalQuantity { get; set; }
    }

    //Offline Order Class
    public class OfflineOrder : IOfflineOrder
    {
        [Required("OfflineOrderID can't be blank.")]
        public Guid OfflineOrderID { get; set; }
        [Required("RetailerID can't be blank.")]
        public Guid RetailerID { get; set; }
        [Required("SalesPersonID can't be blank.")]
        public Guid SalesPersonID { get; set; }
        [Required("Total Quantity can't be blank.")]
        public double TotalQuantity { get; set; }
        [Required("TotalOrderAmount can't be blank.")]
        public double TotalOrderAmount { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

// Created By Prafull 
namespace Capgemini.GreatOutdoor.UnitTests
{
    [TestClass]
    public class AddRetailerBLTest
    {
        /// <summary>
        /// Add Retailer to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task AddValidRetailer()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott1@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Retailer Name can't be null
        /// </summary>
        [TestMethod]
        public async Task RetailerNameCanNotBeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = null, RetailerMobile = "9988776655", Password = "Smith123#", Email = "smith@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Retailer Mobile can't be null
        /// </summary>
        [TestMethod]
        public async Task RetailerMobileCanNotBeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Smith", RetailerMobile = null, Password = "Smith123#", Email = "smith@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Retailer Password can't be null
        /// </summary>
        [TestMethod]
        public async Task RetailerPasswordCanNotBeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Allen", RetailerMobile = "9877766554", Password = null, Email = "allen@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Retailer Email can't be null
        /// </summary>
        [TestMethod]
        public async Task RetailerEmailCanNotBeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "John", RetailerMobile = "9876543210", Password = "John123#", Email = null };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// RetailerName should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task RetailerNameShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "J", RetailerMobile = "9877897890", Password = "John123#", Email = "john@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// RetailerMobile should be a valid mobile number
        /// </summary>
        [TestMethod]
        public async Task RetailerMobileRegExp()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "John", RetailerMobile = "9877", Password = "John123#", Email = "john@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Password should be a valid password as per regular expression
        /// </summary>
        [TestMethod]
        public async Task RetailerPasswordRegExp()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "John", RetailerMobile = "9877897890", Password = "John", Email = "john@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task RetailerEmailRegExp()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "John", RetailerMobile = "9877897890", Password = "John123#", Email = "john" };
            bool isAdded = false;
            string errorMessage = null;
            Guid newGuid;

            //Act
            try
            {
                (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }
    /// <summary>
    /// For Updating Reatiler
    /// </summary>
    [TestClass]
    public class UpdateRetailerTestBL
    {
        /// <summary>
        /// Update  to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdateValidRetailer()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott19@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.RetailerName = "John";
            retailer.Email = "ram10@capgemini.com";
            string errorMessage = null;


            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task RetailerEmailRegExp()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott17@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.RetailerName = "John";
            retailer.Email = "John@capgemi";
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Name  should not be null
        /// </summary>
        [TestMethod]
        public async Task NameShouldNotBeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott16@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.RetailerName = null;
            retailer.Email = "John@capgemi";
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Email should not be null
        /// </summary>
        [TestMethod]
        public async Task RetailerEmailShouldNotbeNull()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott15@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.RetailerName = "John";
            retailer.Email = null;
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task RetailerNameShouldContainMoreThan2character()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott17@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.RetailerName = "J";
            retailer.Email = "John@capgemi";
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Update  to the Retailer Password if it is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdatePasswordRatilerBLTest()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott11@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.Password = "Prafull123#";
            string errorMessage = null;


            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerPasswordBL(retailer);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Fail to update retailer Password
        /// </summary>
        [TestMethod]
        public async Task FailedtoUpdateRetailerPasswordBLTest()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Scott", RetailerMobile = "9876543210", Password = "Scott123#", Email = "scott12@gmail.com" };
            bool isAdded = false;
            bool isUpdated = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            retailer.Password = "Praf";
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await retailerBL.UpdateRetailerPasswordBL(retailer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }


    }




    /// <summary>
    /// For Getting Reatiler By ID
    /// </summary>
    [TestClass]
    public class GettingRetailerByIDBLTest
    {
        /// <summary>
        /// Get Retailer if it is valid if it is valid.
        /// </summary>
        [TestMethod]
        public async Task GetRetailerByReailerIDBLTest()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram3@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;


            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByRetailerIDBL(newGuid);
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isGet, errorMessage);
            }
        }

        /// <summary>
        /// Fail to get Retailer By Retailer ID
        /// </summary>
        [TestMethod]
        public async Task FailtoGetRetailerByRetailerID()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram2@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;
            Guid newGuid1 = new Guid();


            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByRetailerIDBL(newGuid1);
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isGet, errorMessage);
            }
        }


        /// <summary>
        /// Get Retailer if it is valid if it is valid.
        /// </summary>
        [TestMethod]
        public async Task GetRetailerByEmailIDBLTest()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;


            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByEmailBL("ram@gmail.com");
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isGet, errorMessage);
            }
        }

        /// <summary>
        /// Fail to get Retailer By Retailer ID
        /// </summary>
        [TestMethod]
        public async Task FailtoGetRetailerByEmailID()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram1@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;
            Guid newGuid1 = new Guid();


            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByEmailBL("ram@yahoo.in");
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isGet, errorMessage);
            }
        }

        /// <summary>
        /// Get Retailer if it is Email and Password if it is valid.
        /// </summary>
        [TestMethod]
        public async Task GetRetailerByEmailandPassword()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram11@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;


            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByEmailAndPasswordBL("ram@gmail.com", "Ramsita123#");
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isGet, errorMessage);
            }
        }

        /// <summary>
        /// Fail to get Retailer By Email and Password
        /// </summary>
        [TestMethod]
        public async Task FailtoGetRetailerByEmailandPassword()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram12@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;
            //Act
            try
            {
                Retailer retailer1 = await retailerBL.GetRetailerByEmailAndPasswordBL("ram@yahoo.in", "Ramsita123#");
                if (retailer1 != null)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isGet, errorMessage);
            }
        }


        /// <summary>
        /// Get Retailer By Retailer Name.
        /// </summary>
        [TestMethod]
        public async Task GetRetailerByRetailerNameBLTest()
        {
            //Arrange
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram15@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;


            //Act
            try
            {
                List<Retailer> retailer1 = await retailerBL.GetRetailersByNameBL("Ram");
                if (retailer1.Count >= 0)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isGet, errorMessage);
            }
        }

        /// <summary>
        /// Fail to get Retailer By Name
        /// </summary>
        [TestMethod]
        public async Task FailtoGetRetailerByRetailerName()
        {
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = new Retailer() { RetailerName = "Ram", RetailerMobile = "8796672977", Password = "Ramsita123#", Email = "ram16@gmail.com" };
            bool isAdded = false;
            bool isGet = false;
            Guid newGuid;
            (isAdded, newGuid) = await retailerBL.AddRetailerBL(retailer);
            string errorMessage = null;
            //Act
            try
            {
                List<Retailer> retailer1 = await retailerBL.GetRetailersByNameBL("shya");
                if (retailer1.Count > 0)
                {
                    isGet = true;
                }
            }
            catch (Exception ex)
            {
                isGet = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isGet, errorMessage);
            }
        }
    }



}



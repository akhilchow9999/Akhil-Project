﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Developd by Ayush Agrawal
namespace Capgemini.GreatOutdoor.Helpers
{
    public enum PurposeOfReturn
    {
        UnsatiSfactoryProduct, WrongProductShipped, WrongProductOrdered, DefectiveProduct
    }
}

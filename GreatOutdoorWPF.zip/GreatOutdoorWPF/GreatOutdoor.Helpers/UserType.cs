﻿namespace Capgemini.GreatOutdoor.Helpers
{
    /// <summary>
    /// developed by sravani
    /// Type of user (i.e, either admin/salesperson/retailer/anonymous)
    /// </summary>
    public enum UserType
    {
        Admin, SalesPerson, Retailer, Anonymous
    }
}
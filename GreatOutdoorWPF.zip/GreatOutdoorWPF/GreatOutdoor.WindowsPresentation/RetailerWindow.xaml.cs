﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for RetailerWindow.xaml
    /// </summary>
    public partial class RetailerWindow : Window
    {
        public RetailerWindow()
        {
            //inialize object Component
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

        }


        //method to give input to Address Click menu
        private void Menu_Address_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new AddressWindow();
            window.Show();
        }
        //method to give  input to Online Return Menu
        private void OnlineReturn_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OnlineReturnsWindow();
            window.Show();
        }
        //method to  input to Delete Account Click 
        private async void DeleteAccount_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                using (RetailerBL retailerBL = new RetailerBL())
                {
                    Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                    bool isDeleted = false;
                    isDeleted = await retailerBL.DeleteRetailerBL(retailer.RetailerID);
                    if (isDeleted)
                    {
                        MessageBox.Show("Account Deleted");
                        Hide();
                        Window window = new MainWindow();
                        window.Show();
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        //method to give  input to Order Click Menu

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OrderWindow();
            window.Show();
        }
    }
}

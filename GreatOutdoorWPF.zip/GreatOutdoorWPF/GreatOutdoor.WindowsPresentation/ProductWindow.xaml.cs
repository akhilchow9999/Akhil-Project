﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        public ProductWindow()
        {
            InitializeComponent();
        }

        // event to fetch all the products from the database table on the click of a button
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            IProductBL productBL = new ProductBL();
            List<Product> tempList = new List<Product>();
            tempList = await productBL.GetAllProductsBL();
            dgvData.ItemsSource = tempList;
            lblStatus.Content = "fetched rows" + tempList.Count.ToString();

        }

        //event to fetch all the products of a particular category on changing selection
        private async void CmbType1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IProductBL productBL = new ProductBL();
            List<Product> tempList = new List<Product>();
            Category category;
            if (cmbType1.Text == "Camping Equipment")
            {
                category = Category.CampingEquipment;
            }
            else if (cmbType1.Text == "Golf Equipment")
            {
                category = Category.GolfEquipment;
            }
            else if (cmbType1.Text == "Mountaineering Equipment")
            {
                category = Category.MountaineeringEquipment;
            }
            else if (cmbType1.Text == "Outdoor Protection")
            {
                category = Category.OutdoorProtection;
            }
            else if (cmbType1.Text == "Personal Accessories")
            {
                category = Category.PersonalAccessories;
            }
            else
            {
                category = Category.CampingEquipment;
            }

            tempList = await productBL.GetProductsByProductCategoryBL(category);
            dgvData.ItemsSource = tempList;

        }

        //event to get a particular product based on the number enetered by the user on the click of a button
        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            IProductBL productBL = new ProductBL();
            Product tempProduct = new Product();
            List<Product> tempList = new List<Product>();
            tempProduct = await productBL.GetProductByProductNumberBL(Convert.ToInt32(numberText.Text));
            tempList.Add(tempProduct);
            dgvData.ItemsSource = tempList;
        }

        //event to switch to a different window on the click of a button
        private void BtnAdd1_Click(object sender, RoutedEventArgs e)
        {
            Window window = new Add_Product();
            window.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Menu_Admin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new Adminmenu();
            window.Show();

        }
    }
}

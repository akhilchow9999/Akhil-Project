﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;


namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for CartWindow.xaml
    /// </summary>
    public partial class CartWindow : Window
    {
        IAddressBL addressBL = new AddressBL();
        List<Address> addresses = new List<Address>();
        OrderDetail orderDetail = new OrderDetail();
        IOrderDetailBL orderDetailBL = new OrderDetailBL();
        OrderWindow OrderWindow = new OrderWindow();
        List<OrderDetail> orderDetails = OrderWindow.orderDetails;
        Guid temp;
        public CartWindow()
        {
            InitializeComponent();
        }

        //method to give number as a input to quantity textbox
        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int i;
            return (int.TryParse(str, out i) && i >= 1 && i <= 99);
        }

        private void BtnConfirmCart_Click(object sender, RoutedEventArgs e)
        {
            if(MessageBox.Show("Confirm Order?", "GreatOutdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                //OrderWindow object to get orderdetails and order object
                OrderWindow OrderWindow = new OrderWindow();
                List<OrderDetail> orderDetails = OrderWindow.orderDetails;
                Order order = OrderWindow.order;
                double TotalAmount = 0;
                int Quantity = 0;
                //to get the total amount and quantity of order
                foreach (OrderDetail orderDetail in orderDetails)
                {
                    TotalAmount += orderDetail.TotalAmount;
                    Quantity += orderDetail.ProductQuantityOrdered;
                }
                order.TotalQuantity = Quantity;
                order.OrderAmount = TotalAmount;
                //assigning total aquantity and amount to order object
                IOrderBL orderBL = new OrderBL();
                orderBL.UpdateOrderBL(order);
                MessageBox.Show($"Order placed! \n Order Amount= {order.OrderAmount} \n Total Quantity= {order.TotalQuantity}");

            }
        }

       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            gridOrderDetails.ItemsSource = orderDetails;

        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new RetailerWindow();
            window.Show();
        }

        private void BtnGoToMenu_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OrderWindow();
            window.Show();
        }

        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Update?", "GreatOutdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                ProductBL productBL = new ProductBL();
                List<Product> products = await productBL.GetProductsByProductNameBL(txtProduct.Text.ToString());
                orderDetail.ProductID = products[0].ProductID;
                orderDetail.ProductName = products[0].ProductName;
                orderDetail.ProductPrice = products[0].ProductPrice;
                orderDetail.LastModifiedDateTime = DateTime.Now;
                orderDetail.DateOfOrder = OrderWindow.order.DateOfOrder;
                txtCartTotal.Text = (Convert.ToDouble(txtCartUnitPrice.Text) * Convert.ToInt32(txtCartQuantity.Text)).ToString();
                orderDetail.OrderDetailId = temp;
                orderDetail.ProductQuantityOrdered = Convert.ToInt32(txtCartQuantity.Text);
                orderDetail.TotalAmount = Convert.ToDouble(txtCartTotal.Text);
                orderDetail.AddressId = Guid.Parse(cmbCartAddress.SelectedValue.ToString());
                orderDetail.OrderId = OrderWindow.order.OrderId;
                await orderDetailBL.UpdateOrderDetailsBL(orderDetail);
                OrderWindow.orderDetails.Add(orderDetail);
                gridOrderDetails.ItemsSource = orderDetails;

            }
        }
        private async void GridOrderDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int i = gridOrderDetails.SelectedIndex;
            if(i<0)
            {
                return;
            }
            else
            {
                txtProduct.IsEnabled = true;
                txtCartTotal.IsEnabled = true;
                txtCartTotal.Text = "0";
                txtCartQuantity.IsEnabled = true;
                cmbCartAddress.IsEnabled = true;
                btnUpdate.IsEnabled = true;
                temp = orderDetails[i].OrderDetailId;
                txtProduct.Text = getCellData(gridOrderDetails, i, 0);
                txtCartUnitPrice.Text = getCellData(gridOrderDetails, i, 2);
                txtCartTotal.Text = getCellData(gridOrderDetails, i, 3);
                txtCartQuantity.Text = getCellData(gridOrderDetails, i, 1);
                addresses = await addressBL.GetAddressByRetailerIDBL(OrderWindow.retailer.RetailerID);
                cmbCartAddress.ItemsSource = addresses;
                cmbCartAddress.DisplayMemberPath = "AddressLine1";
                cmbCartAddress.SelectedValuePath = "AddressID";
               
            }
        }
        

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow = dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }

        

        private void CmbCartAddress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            orderDetail.AddressId = Guid.Parse(cmbCartAddress.SelectedValue.ToString());
        }

        private void TxtCartQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtCartQuantity.Text == "")
            {
                MessageBox.Show("Enter a Number in Quantity");
            }

            //giving total amount based on quantity input
            else
            {

                txtCartTotal.Text = (Convert.ToDouble(txtCartUnitPrice.Text) * Convert.ToInt32(txtCartQuantity.Text)).ToString();
                orderDetail.ProductQuantityOrdered = Convert.ToInt32(txtCartQuantity.Text);
                orderDetail.TotalAmount = Convert.ToDouble(txtCartTotal.Text);
            }
        }
    }
}
